#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include "DHT.h"
#include "Adafruit_SGP30.h"
#include <SDS011.h> 

#define DHTPIN 13
#define DHTTYPE DHT22
#define LEDPIN 21
#define RXD2 18  // SDS011 RX
#define TXD2 17  // SDS011 TX

#define PM25_THRESHOLD 35.0   // µg/m³
#define PM10_THRESHOLD 50.0   // µg/m³
#define TVOC_THRESHOLD 500    // ppb
#define ECO2_THRESHOLD 1000  // ppm

const char* ssid = "ATTmtSBq2N";
const char* password = "t8rwd4u#byxa";
const char* serverURL = "http://3.147.49.233:5000/data";

DHT dht(DHTPIN, DHTTYPE);
Adafruit_SGP30 sgp;
SDS011 sds;
WiFiClient client;

float pm25, pm10;

uint32_t getAbsoluteHumidity(float temperature, float humidity) {
  return static_cast<uint32_t>(216.7f * ((humidity / 100.0f) * 6.112f *
         exp((17.62f * temperature) / (243.12f + temperature)) /
         (273.15f + temperature)) * 1000.0f);
}

void blinkLED(int times, int delayMs) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LEDPIN, LOW);
    delay(delayMs);
    digitalWrite(LEDPIN, HIGH);
    delay(delayMs);
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LEDPIN, OUTPUT);
  digitalWrite(LEDPIN, LOW);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected");
  digitalWrite(LEDPIN, HIGH);

  dht.begin();
  Serial2.begin(9600, SERIAL_8N1, RXD2, TXD2);
  sds.begin(&Serial2);

  Wire.begin(44, 43); // SDA, SCL
  if (!sgp.begin()) {
    Serial.println("❌ SGP30 not found!");
    while (true) delay(1000);
  }
  sgp.setHumidity(getAbsoluteHumidity(dht.readTemperature(), dht.readHumidity()));
}

void loop() {
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  if (isnan(h) || isnan(t)) {
    Serial.println("Failed to read from DHT22!");
    return;
  }

  sgp.IAQmeasure();
  sds.read(&pm25, &pm10);

  Serial.printf(" Temp: %.2f°C   Humidity: %.2f%%\n", t, h);
  Serial.printf(" eCO2: %d ppm, TVOC: %d\n", sgp.eCO2, sgp.TVOC);
  Serial.printf(" PM2.5: %.2f µg/m³, PM10: %.2f\n", pm25, pm10);

  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(serverURL);
    http.addHeader("Content-Type", "application/json");

    DynamicJsonDocument doc(256);
    doc["temp"] = t;
    doc["humidity"] = h;
    doc["pm25"] = pm25;
    doc["pm10"] = pm10;
    doc["eco2"] = sgp.eCO2;
    doc["tvoc"] = sgp.TVOC;

    String payload;
    serializeJson(doc, payload);
    int response = http.POST(payload);
    Serial.print(" POST response: "); Serial.println(response);
    http.end();
  }

  // Check air quality and blink LED if polluted
  bool polluted = false;
  if (pm25 > PM25_THRESHOLD || pm10 > PM10_THRESHOLD ||
      sgp.TVOC > TVOC_THRESHOLD || sgp.eCO2 > ECO2_THRESHOLD) {
    polluted = true;
    Serial.println("⚠️ Air pollution detected! Blinking LED.");
    blinkLED(3, 300);  // Blink 3 times
  } else {
    digitalWrite(LEDPIN, HIGH);  // Stay ON if clean
  }

  delay(5000);
}
